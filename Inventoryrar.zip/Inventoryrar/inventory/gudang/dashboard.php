<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Dashboard</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="#">
									<i class="flaticon-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="#">Dashboard</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="#">Dashboard</a>
							</li>
						</ul>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<center><h3>RANCANG BANGUN SISTEM INFORMASI</h3>
									<h4>PENGENDALIAN PERSEDIAN BARANG</h4>
									<h4>PADA PT PARAGON TECHNOLOGY AND INNOVATION</h4></center>
								</div>
							</div>
						</div>
					</div>
				</div>